class StudentAgent:
    def analyze(self, code: str):
        lines = code.strip().split("\n")
        result = []

        for i, line in enumerate(lines):
            line = line.strip()

            if "for" in line:
                result.append(f"Line {i}: loop start -> {line}")
            elif "if" in line:
                result.append(f"Line {i}: condition -> {line}")
            elif "*" in line and "=" in line:
                result.append(f"Line {i}: pointer operation -> {line}")
            elif "=" in line:
                result.append(f"Line {i}: assignment -> {line}")
            elif "return" in line:
                result.append(f"Line {i}: return -> {line}")
            else:
                result.append(f"Line {i}: statement -> {line}")

        return result
