class TeacherAgent:
    def to_mermaid(self, student_output):
        mermaid = ["flowchart TD"]

        for i, step in enumerate(student_output):
            node = f"N{i}[{step}]"
            mermaid.append(node)

            if i > 0:
                mermaid.append(f"N{i-1} --> N{i}")

        return "\n".join(mermaid)
