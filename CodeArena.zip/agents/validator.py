class ValidatorAgent:
    def validate(self, code, student_output, mermaid):
        errors = []

        if "return" in code and not any("return" in s for s in student_output):
            errors.append("Missing return logic")

        if "*" in code and not any("pointer" in s for s in student_output):
            errors.append("Pointer logic not captured")

        if "flowchart" not in mermaid:
            errors.append("Invalid mermaid output")

        return errors
