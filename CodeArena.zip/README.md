# CodeArena

A multi-agent system for C code reasoning, execution flow inference, and flowchart generation.

## Features
- Multi-agent architecture (Student / Teacher / Validator)
- Step-by-step C code analysis
- Automatic Mermaid flowchart generation
- Iterative validation loop

## Demo
```bash
python main.py
```

## Architecture
C Code → Student → Teacher → Validator → Loop

## Future Work
- AST parsing with tree-sitter
- GCC execution validation
- LLM integration
- Web UI
