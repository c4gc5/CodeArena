from agents.student import StudentAgent
from agents.teacher import TeacherAgent
from agents.validator import ValidatorAgent


class MultiAgentSystem:
    def __init__(self):
        self.student = StudentAgent()
        self.teacher = TeacherAgent()
        self.validator = ValidatorAgent()

    def run(self, code):
        for round in range(3):
            print(f"\n--- Round {round+1} ---")

            student_output = self.student.analyze(code)
            mermaid = self.teacher.to_mermaid(student_output)
            errors = self.validator.validate(code, student_output, mermaid)

            print("\n[Student Output]")
            print("\n".join(student_output))

            print("\n[Mermaid]")
            print(mermaid)

            print("\n[Validator]")
            if not errors:
                print("✔ Passed")
                return mermaid
            else:
                print("✘ Errors:", errors)

        return "Failed after retries"


if __name__ == "__main__":
    c_code = """
    int sum(int *arr, int n){
        int s = 0;
        for(int i=0;i<n;i++){
            s += arr[i];
        }
        return s;
    }
    """

    system = MultiAgentSystem()
    system.run(c_code)
